//! Gerätezugriff und Hintergrunddienst.
use crate::actions::{self, Action};
use crate::config::{Config, InputMap, Twist, KEY_COUNT};
use crate::render;
use anyhow::{bail, Result};
use futures_lite::StreamExt;
use mirajazz::{
    device::{list_devices, new_hid_backend, Device, DeviceQuery},
    types::{DeviceInput, HidDeviceInfo, ImageFormat, ImageMirroring, ImageMode, ImageRotation},
};
use std::time::{Duration, Instant, SystemTime};
use tokio::sync::mpsc;

const USAGE_PAGE: u16 = 65440;
const USAGE_ID: u16 = 1;
/// Protokollversion 3, laut mirajazz-N1-Beispiel.
const PROTOCOL_VERSION: usize = 3;
/// Betriebsmodus "Software" (1 = Ziffernblock, 2 = Rechner).
const MODE_SOFTWARE: u8 = 3;

pub enum Control {
    Reload,
    Quit,
}

#[derive(Clone, Copy, Debug)]
pub struct Raw {
    pub code: u8,
    pub state: u8,
}

#[derive(Debug, PartialEq, Eq)]
enum Input {
    Key(usize),
    KnobPress,
    KnobCw,
    KnobCcw,
}

fn image_format(key: usize) -> ImageFormat {
    ImageFormat {
        mode: ImageMode::JPEG,
        size: if key >= 15 { (64, 64) } else { (96, 96) },
        rotation: ImageRotation::Rot0,
        mirror: ImageMirroring::None,
    }
}

fn classify(map: &InputMap, raw: Raw) -> Option<Input> {
    if raw.code == 0 {
        return None;
    }
    // Drehungen zuerst: Sie dürfen nicht als Tastendruck gelten.
    if map.knob_cw.code != 0 && raw.code == map.knob_cw.code && raw.state == map.knob_cw.state {
        return Some(Input::KnobCw);
    }
    if map.knob_ccw.code != 0 && raw.code == map.knob_ccw.code && raw.state == map.knob_ccw.state {
        return Some(Input::KnobCcw);
    }
    if raw.state == 0 {
        return None;
    }
    if map.knob_press != 0 && raw.code == map.knob_press {
        return Some(Input::KnobPress);
    }
    map.button_codes.iter().position(|c| *c == raw.code).map(Input::Key)
}

/// Bekannte VID/PID-Kombinationen des N1 (erste = aus der Config).
/// 6603:1000 stammt aus dem mirajazz-Beispiel, 5548:1038/1032 aus den VSD-Craft-Logs.
const KNOWN_IDS: [(u16, u16); 3] = [(0x6603, 0x1000), (0x5548, 0x1038), (0x5548, 0x1032)];

pub async fn find_device(cfg: &Config) -> Option<mirajazz::types::HidDevice> {
    let mut ids = vec![(cfg.device.vid, cfg.device.pid)];
    ids.extend(KNOWN_IDS);
    let queries: Vec<DeviceQuery> = ids
        .into_iter()
        .map(|(v, p)| DeviceQuery::new(USAGE_PAGE, USAGE_ID, v, p))
        .collect();
    list_devices(&queries).await.ok()?.into_iter().next()
}

async fn open(info: &HidDeviceInfo) -> Result<Device> {
    let device = Device::connect(info, PROTOCOL_VERSION, KEY_COUNT, 0).await?;
    device.set_mode(MODE_SOFTWARE).await?;
    tokio::time::sleep(Duration::from_millis(50)).await;
    Ok(device)
}

/// Liest Rohpakete in einem eigenen Task und schickt sie über einen Kanal.
fn spawn_reader(device: &Device) -> mpsc::UnboundedReceiver<Result<Raw, String>> {
    let reader = device.get_reader(|_, _| Ok(DeviceInput::NoData));
    let (tx, rx) = mpsc::unbounded_channel();
    tokio::spawn(async move {
        loop {
            match reader.raw_read_data(512).await {
                Ok(data) => {
                    if data.len() > 10 && data.starts_with(&[65, 67, 75]) {
                        let _ = tx.send(Ok(Raw { code: data[9], state: data[10] }));
                    }
                }
                Err(e) => {
                    let _ = tx.send(Err(e.to_string()));
                    break;
                }
            }
        }
    });
    rx
}

async fn draw_images(device: &Device, images: Vec<(usize, image::DynamicImage)>) -> Result<()> {
    device.clear_all_button_images().await?;
    for (i, img) in images {
        device.set_button_image(i as u8, image_format(i), img).await?;
    }
    device.flush().await?;
    Ok(())
}

async fn draw_page(device: &Device, cfg: &Config, page: &str) -> Result<()> {
    // Schrift nur kurz im Speicher halten.
    let font = render::load_font(cfg);
    let images = (0..KEY_COUNT)
        .map(|i| (i, render::render_key(cfg.key_on_page(page, i), i, font.as_ref())))
        .collect();
    drop(font);
    draw_images(device, images).await
}

enum End {
    Quit,
    Disconnected,
}

fn reload(cfg: &mut Config, mtime: &mut Option<SystemTime>) -> bool {
    match Config::load() {
        Ok(c) => {
            *cfg = c;
            *mtime = Config::mtime();
            true
        }
        Err(e) => {
            eprintln!("Config konnte nicht geladen werden: {e:#}");
            *mtime = Config::mtime();
            false
        }
    }
}

async fn session(
    info: &HidDeviceInfo,
    cfg: &mut Config,
    mtime: &mut Option<SystemTime>,
    ctl: &mut mpsc::UnboundedReceiver<Control>,
) -> Result<End> {
    let device = open(info).await?;
    let mut page = cfg.start_page.clone();
    device.set_brightness(cfg.brightness).await?;
    draw_page(&device, cfg, &page).await?;
    let mut rx = spawn_reader(&device);

    let mut tick = tokio::time::interval(Duration::from_secs(2));
    let mut last_keep_alive = Instant::now();

    loop {
        tokio::select! {
            ev = rx.recv() => {
                let raw = match ev {
                    Some(Ok(raw)) => raw,
                    Some(Err(e)) => { eprintln!("Lesefehler: {e}"); return Ok(End::Disconnected); }
                    None => return Ok(End::Disconnected),
                };
                let action = match classify(&cfg.input, raw) {
                    Some(Input::Key(i)) => cfg.key_on_page(&page, i).map(|k| k.action.clone()),
                    Some(Input::KnobPress) => Some(cfg.knob.press.clone()),
                    Some(Input::KnobCw) => Some(cfg.knob.cw.clone()),
                    Some(Input::KnobCcw) => Some(cfg.knob.ccw.clone()),
                    None => None,
                };
                match action {
                    Some(Action::Page { to }) => {
                        if cfg.pages.contains_key(&to) {
                            page = to;
                            draw_page(&device, cfg, &page).await?;
                        } else {
                            eprintln!("Seite '{to}' existiert nicht");
                        }
                    }
                    Some(a) => {
                        let obs = cfg.obs.clone();
                        tokio::spawn(async move { actions::execute(&a, &obs).await });
                    }
                    None => {}
                }
            }
            c = ctl.recv() => match c {
                Some(Control::Reload) => {
                    if reload(cfg, mtime) {
                        if !cfg.pages.contains_key(&page) { page = cfg.start_page.clone(); }
                        device.set_brightness(cfg.brightness).await?;
                        draw_page(&device, cfg, &page).await?;
                    }
                }
                Some(Control::Quit) | None => {
                    let _ = device.shutdown().await;
                    return Ok(End::Quit);
                }
            },
            _ = tick.tick() => {
                if cfg.keep_alive_secs > 0 && last_keep_alive.elapsed().as_secs() >= cfg.keep_alive_secs {
                    device.keep_alive().await?;
                    last_keep_alive = Instant::now();
                }
                let now = Config::mtime();
                if now != *mtime {
                    if reload(cfg, mtime) {
                        if !cfg.pages.contains_key(&page) { page = cfg.start_page.clone(); }
                        device.set_brightness(cfg.brightness).await?;
                        draw_page(&device, cfg, &page).await?;
                    }
                }
            }
        }
    }
}

/// Hauptschleife des Dienstes: wartet auf das Gerät, hält die Sitzung, verbindet neu.
pub async fn run(mut ctl: mpsc::UnboundedReceiver<Control>) {
    let mut cfg = Config::load_or_create();
    let mut mtime = Config::mtime();
    loop {
        let info = loop {
            if let Some(i) = find_device(&cfg).await {
                break i;
            }
            match tokio::time::timeout(Duration::from_secs(2), ctl.recv()).await {
                Ok(Some(Control::Quit)) | Ok(None) => return,
                Ok(Some(Control::Reload)) => {
                    reload(&mut cfg, &mut mtime);
                }
                Err(_) => {
                    if Config::mtime() != mtime {
                        reload(&mut cfg, &mut mtime);
                    }
                }
            }
        };
        match session(&info, &mut cfg, &mut mtime, &mut ctl).await {
            Ok(End::Quit) => return,
            Ok(End::Disconnected) => {}
            Err(e) => eprintln!("Sitzung beendet: {e:#}"),
        }
        tokio::time::sleep(Duration::from_secs(1)).await;
    }
}

// ---------------------------------------------------------------- Hilfsbefehle

/// Listet alle HID-Geräte (um VID/PID des N1 zu prüfen).
pub async fn list() -> Result<()> {
    let backend = new_hid_backend();
    let mut stream = backend.enumerate().await?;
    while let Some(d) = stream.next().await {
        println!(
            "{:04X}:{:04X}  usage {}/{}  {}",
            d.vendor_id, d.product_id, d.usage_page, d.usage_id, d.name
        );
    }
    Ok(())
}

async fn connect_for_tools() -> Result<(Device, mpsc::UnboundedReceiver<Result<Raw, String>>, Config)> {
    let cfg = Config::load_or_create();
    let Some(info) = find_device(&cfg).await else {
        bail!(
            "Kein Gerät mit {:04X}:{:04X} gefunden. `n1deck list` zeigt alle HID-Geräte; \
             VID/PID ggf. in der Config unter [device] anpassen. Läuft VSD Craft noch? Bitte beenden.",
            cfg.device.vid,
            cfg.device.pid
        );
    };
    let device = open(&info).await?;
    device.set_brightness(cfg.brightness).await?;
    let rx = spawn_reader(&device);
    Ok((device, rx, cfg))
}

/// Gibt alle Rohcodes aus.
pub async fn probe() -> Result<()> {
    let (_device, mut rx, _) = connect_for_tools().await?;
    println!("Drücke Tasten / drehe den Regler. Beenden mit Strg+C.");
    while let Some(ev) = rx.recv().await {
        match ev {
            Ok(r) => println!("code={:#04x} ({})  state={}", r.code, r.code, r.state),
            Err(e) => bail!("Lesefehler: {e}"),
        }
    }
    Ok(())
}

async fn wait_press(
    rx: &mut mpsc::UnboundedReceiver<Result<Raw, String>>,
    accept: impl Fn(Raw) -> bool,
) -> Result<Raw> {
    let deadline = Duration::from_secs(60);
    loop {
        match tokio::time::timeout(deadline, rx.recv()).await {
            Ok(Some(Ok(r))) if accept(r) => return Ok(r),
            Ok(Some(Ok(_))) => {}
            Ok(Some(Err(e))) => bail!("Lesefehler: {e}"),
            Ok(None) => bail!("Gerät getrennt"),
            Err(_) => bail!("Zeitüberschreitung (60 s) – abgebrochen, nichts gespeichert"),
        }
    }
}

/// Geführtes Einlernen: Tasten zeigen ihre Nummer, du drückst sie der Reihe nach.
pub async fn learn() -> Result<()> {
    let (device, mut rx, mut cfg) = connect_for_tools().await?;
    let mut map = InputMap { button_codes: vec![0; KEY_COUNT], ..Default::default() };

    println!("Einlernen. Jede Taste zeigt jetzt ihre Nummer (0–17).");
    for i in 0..KEY_COUNT {
        let images = (0..KEY_COUNT).map(|k| (k, render::render_number(k, k, k == i))).collect();
        draw_images(&device, images).await?;
        println!("Drücke die Taste mit der orange hinterlegten Nummer {i} …");
        let used = map.button_codes.clone();
        let r = wait_press(&mut rx, |r| r.state != 0 && r.code != 0 && !used.contains(&r.code)).await?;
        println!("  Taste {i} = Code {:#04x}", r.code);
        map.button_codes[i] = r.code;
        tokio::time::sleep(Duration::from_millis(300)).await; // Loslassen abwarten
        while rx.try_recv().is_ok() {}
    }

    let used = map.button_codes.clone();
    println!("Drücke jetzt den Drehregler (Klick) …");
    let r = wait_press(&mut rx, |r| r.state != 0 && r.code != 0 && !used.contains(&r.code)).await?;
    map.knob_press = r.code;
    println!("  Regler-Klick = Code {:#04x}", r.code);
    tokio::time::sleep(Duration::from_millis(300)).await;
    while rx.try_recv().is_ok() {}

    println!("Drehe den Regler EINEN Schritt nach rechts (im Uhrzeigersinn) …");
    let press = map.knob_press;
    let r = wait_press(&mut rx, |r| r.code != 0 && !used.contains(&r.code) && (r.code != press || r.state > 1)).await?;
    map.knob_cw = Twist { code: r.code, state: r.state };
    println!("  rechts = Code {:#04x}, state {}", r.code, r.state);
    tokio::time::sleep(Duration::from_millis(400)).await;
    while rx.try_recv().is_ok() {}

    println!("Drehe den Regler EINEN Schritt nach links …");
    let cw = map.knob_cw;
    let r = wait_press(&mut rx, |r| {
        r.code != 0 && !used.contains(&r.code) && !(r.code == cw.code && r.state == cw.state) && (r.code != press || r.state > 1)
    })
    .await?;
    map.knob_ccw = Twist { code: r.code, state: r.state };
    println!("  links = Code {:#04x}, state {}", r.code, r.state);

    cfg.input = map;
    cfg.save()?;
    let page = cfg.start_page.clone();
    draw_page(&device, &cfg, &page).await?;
    println!("Fertig. Zuordnung in {} gespeichert.", crate::config::config_path().display());
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn map() -> InputMap {
        let mut codes = vec![0u8; KEY_COUNT];
        for (i, c) in codes.iter_mut().enumerate() {
            *c = i as u8 + 1;
        }
        InputMap {
            button_codes: codes,
            knob_press: 0x25,
            knob_cw: Twist { code: 0x91, state: 1 },
            knob_ccw: Twist { code: 0x90, state: 1 },
        }
    }

    #[test]
    fn classifies_inputs() {
        let m = map();
        assert_eq!(classify(&m, Raw { code: 3, state: 1 }), Some(Input::Key(2)));
        assert_eq!(classify(&m, Raw { code: 3, state: 0 }), None); // Loslassen
        assert_eq!(classify(&m, Raw { code: 0x25, state: 1 }), Some(Input::KnobPress));
        assert_eq!(classify(&m, Raw { code: 0x91, state: 1 }), Some(Input::KnobCw));
        assert_eq!(classify(&m, Raw { code: 0x90, state: 1 }), Some(Input::KnobCcw));
        assert_eq!(classify(&InputMap::default(), Raw { code: 3, state: 1 }), None);
    }
}
