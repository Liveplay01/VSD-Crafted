//! n1deck – schlanker Ersatz für VSD Craft (Basicolor / VSD N1).
pub mod actions;
pub mod config;
pub mod keys;
pub mod obs;
pub mod render;
pub mod service;
