# n1deck – schlanker Ersatz für VSD Craft (VSD / Basicolor N1)

Rust-Dienst mit Tray-Icon (kein Chromium, kein Node) plus kleine Config-GUI (`n1deck-config`).
Protokoll: Bibliothek `mirajazz`.

## Bauen (Windows)
Variante A – GitHub: Ordner als Repo pushen, unter *Actions → build-windows* die `.exe`s als Artefakt laden.
Variante B – lokal: Rust (rustup) + Visual-Studio-Build-Tools, dann `cargo build --release`.
Ergebnis: `target\release\n1deck.exe` und `n1deck-config.exe` (im selben Ordner lassen).

## Einrichten (einmalig, VSD Craft vorher beenden!)
1. `n1deck list`   – N1 in der Liste suchen (VID:PID). Weicht sie von 6603:1000 / 5548:1038 / 5548:1032 ab,
   in `%APPDATA%\n1deck\config.toml` unter `[device]` eintragen (Dezimalwerte).
2. `n1deck probe`  – Tasten drücken, es müssen Codes erscheinen. Wenn nicht: Ausgabe melden.
3. `n1deck learn`  – Tasten zeigen Nummern, der Reihe nach drücken; dann Regler klicken, rechts, links.
4. `n1deck`        – Dienst starten (Tray-Icon). `n1deck autostart on` für Start mit Windows.
5. Rechtsklick Tray → „Konfiguration öffnen“, Tasten belegen, Speichern (wird automatisch übernommen).

## Aktionen
Öffnen (Datei/Ordner/URL), Programm starten, Tastenkombination, Medien/Lautstärke, Seitenwechsel,
OBS (obs-websocket v5; in OBS: Werkzeuge → WebSocket-Servereinstellungen, Passwort in der Config).
Nicht übernehmbar: die originalen VSD-Craft-/Stream-Deck-Plugins (Discord usw.).

## Stand
Getestet nur auf Linux (Unit-Tests, Kompilierung, Leerlauf-RAM). Hardware, Tray, SendInput und
OBS-Anbindung sind ungetestet. Die Tastencodes des N1 sind nicht dokumentiert – deshalb `learn`.
